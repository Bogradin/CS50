#include <stdio.h>
#include <cs50.h>

int main(void)
{
    //Name questioning
    string name = get_string("What's your name? ");
    //Name printing
    printf("hello, %s\n", name);
}
#include <ctype.h>
#include <cs50.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    string word = "hello world";
    for (int i = 0, n = strlen(word); i < n; i++)
    {
        printf("%c\n", word[i]);
    }
}
